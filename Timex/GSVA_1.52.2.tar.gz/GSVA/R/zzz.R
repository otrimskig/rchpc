.onLoad <- function(libname, pkgname) {
  options(Matrix.warnDeprecatedCoerce = 2)
}
