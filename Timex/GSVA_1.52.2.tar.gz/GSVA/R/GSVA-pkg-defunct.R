## GSVA-pkg-defunct.R
#' @title Defunct functions in package `GSVA`.
#' @description The functions listed below are defunct and will be removed
#'   in the next release.
#' @name GSVA-pkg-defunct
#' @keywords internal
NULL

